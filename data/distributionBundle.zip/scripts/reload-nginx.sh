#!/usr/bin/bash
# -*- coding: utf-8 -*-
set -e

nginx -s reload

# region modline
# vim: set tabstop=4 shiftwidth=4 expandtab filetype=dockerfile:
# vim: foldmethod=marker foldmarker=region,endregion:
# endregion
