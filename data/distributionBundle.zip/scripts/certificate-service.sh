#!/usr/bin/env bash
# -*- coding: utf-8 -*-
set -e

source get-bashlink

# Example environment configuration:
# APPLICATION_PATH='./'
#
# PROXY_CERTIFICATES=(service service.staging)
# PROXY_CERTIFICATE_DOMAINS=(
#     'service.com service-variation.com'
#     'service.staging.com service-variation.staging.com'
# )
# PROXY_CERTIFICATE_EMAIL_ADDRESSES=(service@info.com)

if ! [ -f "$CERTIFICATION_SERVICE_LOG" ]; then
    run-command touch "$CERTIFICATION_SERVICE_LOG"
    chmod o+w "$CERTIFICATION_SERVICE_LOG"
fi

# NOTE: Wait a bit before starting to avoid making too many challenges when
# application restarts many times in short period.
declare delay="${PROXY_CERTIFICATES_START_UPDATE_DELAY:-'50m'}"
bl.logging.info \
    "Wait $delay until first certificate update check." \
    &>>"$CERTIFICATION_SERVICE_LOG"
sleep "$delay"

# Defines how often we should reload nginx "1" means on every check and "7" on
# every 7th check for example.
declare RELOAD_NGINX_INTERVAL=7

declare certificate_path
declare domains
declare domain_path
declare email_address
declare index
declare name

declare number_of_intervals=0
while true; do
    for index in "${!PROXY_CERTIFICATES[@]}"; do
        domains=${PROXY_CERTIFICATE_DOMAINS[index]}
        name="${PROXY_CERTIFICATES[index]}"

        bl.logging.info \
            "Start checking certificate \"${name}\"." \
            &>>"$CERTIFICATION_SERVICE_LOG"

        certificate_path="${APPLICATION_PATH}certificates/${name}/"
        mkdir --parents "$certificate_path"

        if [ "${PROXY_CERTIFICATE_EMAIL_ADDRESSES[index]}" != '' ]; then
            email_address="${PROXY_CERTIFICATE_EMAIL_ADDRESSES[index]}"
        fi

        command_line_arguments="${name} '${certificate_path}' '${domains}' '${email_address}'"
        domain_path="${certificate_path}domains.txt"

        # If certificates already exists as specified only update existing ones
        # and retrieve them initially otherwise.
        if \
            [ -f "$domain_path" ] && [ "${domains}" = "$(cat "$domain_path")" ]
        then
            # NOTE: Server configuration file updates have to be run as root to
            # be able to temporary manipulate nginx configuration files:
            eval \
                "update-certificate ${command_line_arguments} &>>'${CERTIFICATION_SERVICE_LOG}'"

            chown \
                --recursive \
                "${MAIN_USER_NAME}:${MAIN_USER_GROUP_NAME}" \
                "${APPLICATION_PATH}certificates" \
                "/tmp/${name}/letsEncryptLog"

            # If we do not use the nginx plugin installer (e.g. using the cli
            # option "--installer null") we can run the renewal as application
            # user and have to reload the server via a certbot hook. But this
            # is not working as long as the pid file is owened by root no
            # matter who starts nginx.

            #run-command \
            #    "APPLICATION_PATH='${APPLICATION_PATH}' update-certificate ${command_line_arguments}"
        else
            rm --force "$domain_path" &>/dev/null || true

            # NOTE: Certbot retrieving have to be run as root to be able to
            # open tcp ports.
            eval \
                "retrieve-certificate ${command_line_arguments} &>>'${CERTIFICATION_SERVICE_LOG}'"
            chown \
                --recursive \
                "${MAIN_USER_NAME}:${MAIN_USER_GROUP_NAME}" \
                "${APPLICATION_PATH}certificates" \
                "/tmp/${name}/letsEncryptLog"
            #run-command
            #    "APPLICATION_PATH='${APPLICATION_PATH}' retrieve-certificate ${command_line_arguments} &>>'${CERTIFICATION_SERVICE_LOG}'"

            echo "${domains}" >"$domain_path"
        fi

        bl.logging.info \
            "Stopped checking certificate \"${name}\"." \
            &>>"$CERTIFICATION_SERVICE_LOG"
    done

    number_of_intervals=$((number_of_intervals + 1))

    if ((number_of_intervals == RELOAD_NGINX_INTERVAL)); then
        bl.logging.info \
            "Reload nginx on ${number_of_intervals}th interval." \
            &>>"$CERTIFICATION_SERVICE_LOG"

        reload-nginx

        number_of_intervals=$((number_of_intervals + 1))
    fi

    bl.logging.info \
        "Wait 24 hours until next certificate update check." \
        &>>"$CERTIFICATION_SERVICE_LOG"
    sleep 24h
done
# region modline
# vim: set tabstop=4 shiftwidth=4 expandtab filetype=dockerfile:
# vim: foldmethod=marker foldmarker=region,endregion:
# endregion
